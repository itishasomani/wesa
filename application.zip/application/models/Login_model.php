<?php
class Login_model extends CI_Model {
    public function login_process(){
        $return_data = $this->login();
        if($return_data['status'] == 1){
            $return_data['response_status'] = 1;
            $return_data['response_msg'] = 'Wellcome';
            $return_data['return_url'] = base_url('admin/dashboard');
        }
        else{
            $return_data['response_status'] = 0;
            $return_data['response_msg'] = 'Invalid Credentials';
            $return_data['return_url'] = base_url('login');
        }
        return $return_data;
    }

    public function login(){
        $return_data = array('status'=>0);
        $this->db->where('email',$this->email);
        $this->db->where('role','admin');
        $data = $this->db->get('user_tbl');
        $row = $data->row_array();
        $password = decrypt($row['password']);
        if(!empty($row)){
            if($password == $this->password){
                $return_data = array('status'=>1);
                $this->setSession($row);
            }
        }
        return $return_data;
    }

    public function setSession($arr){
        $userdata = array(
            'id'=>$arr['id'],
            'name'=>$arr['name'],
            'email'=>$arr['email'],
            'role'=>$arr['role'],
            'admin_login'=>TRUE
        );
        $this->session->set_userdata($userdata);
    }
}
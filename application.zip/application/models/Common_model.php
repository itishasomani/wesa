<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_model extends CI_Model {

	public function get_count($tbl){
        return $this->db->count_all($tbl);
    }
	public function add_leave_management(){
		$str = random_string(5);
			$name = 'file-'.$str;
			$config['upload_path'] = './assets/backend/dist/upload/';
			$config['allowed_types'] = 'jpg|png|jpeg|doc|docx|ppt|pptx|pdf|zip|rar';
			$config['max_size'] = 10000;			
			$config['file_name'] = $name;
			$this->load->library('upload',$config);
			if($this->upload->do_upload('file')){
				$file =  $this->upload->data('file_name');
			}

		$data = array(
			'name'=>$this->name,
			'emp_id'=>$this->emp_id,
			'leave_type'=>$this->leave_type,
			'from'=>$this->from,
			'leave_to'=>$this->leave_to,
			'days'=>$this->days,
			'replacement'=>$this->replacement,
			'approver'=>$this->approver,
			'approver_two'=>$this->approver_two,
			'file'=>$file
		);

		$this->db->insert('leave_manage_tbl',$data);
		$id = $this->db->insert_id();
		if($id > 0){
			$return_data['response_status'] = 1;
			$return_data['response_msg'] = 'Leave has been add';
			$return_data['return_url'] = base_url('admin/leave-management');
		}
		else{
			$return_data['response_status'] = 0;
			$return_data['response_msg'] = 'Leave not add';
			$return_data['return_url'] = base_url('admin/add_leave_management');
		}
	return $return_data;
	}
	public function add_employee(){
    		$str = random_string(5);
			$name = 'image-'.$str;
			$config['upload_path'] = './assets/backend/dist/img/';
			$config['allowed_types'] = 'jpg|png|jpeg';
			$config['max_size'] = 10000;			
			$config['file_name'] = $name;
			$this->load->library('upload',$config);
			if($this->upload->do_upload('image')){
				$image =  $this->upload->data('file_name');
			}
			$data = array(
				'name'=>$this->name,
				'emp_id'=>$this->emp_id,
				'username'=>$this->username,
				'password'=>$this->password,
				'email_id'=>$this->email_id,
				'phone'=>$this->phone,
				'position'=>$this->position,
				'department'=>$this->department,
				'education'=>$this->education,
				'training'=>$this->training,
				'certificate'=>$this->certificate,
				'image'=>$image,
			);
			$this->db->insert('emp_tbl',$data);
			$id = $this->db->insert_id();
			
			if($id > 0){
				$return_data['response_status'] = 1;
				$return_data['response_msg'] = 'employee has been add';
				$return_data['return_url'] = base_url('admin/employee');
			}
			else{
				$return_data['response_status'] = 0;
				$return_data['response_msg'] = 'employee not add';
				$return_data['return_url'] = base_url('admin/add-employee');
			}
    	return $return_data;
	}
	public function get_employee(){
		$row = $this->db->get('emp_tbl')->result_array();
    	return $row;
	}
	public function get_employee_by_id($id){
		$this->db->where('id',$id);
    	$row = $this->db->get('emp_tbl')->row_array();
		// $password = decrypt($row['password']);
    	return $row;
	}
	public function edit_employee(){
		$row = $this->get_employee_by_id($this->id);
		if(!empty($_FILES['image']['name'])){
			$str = random_string(5);
			$name = 'image-'.$str;
			$config['upload_path'] = './assets/backend/dist/img/';
			$config['allowed_types'] = 'jpg|png|jpeg';
			$config['max_size'] = 10000;
			$config['file_name'] = $name;
			$this->load->library('upload',$config);
			if($this->upload->do_upload('image')){
				$image =  $this->upload->data('file_name');
			}
		}
		else{
			$image=  $row['image'];
		}
		$data = array(
			'name'=>$this->name,
			'emp_id'=>$this->emp_id,
			'username'=>$this->username,
			'password'=>$this->password,
			'email_id'=>$this->email_id,
			'phone'=>$this->phone,
			'position'=>$this->position,
			'department'=>$this->department,
			'education'=>$this->education,
			'training'=>$this->training,
			'certificate'=>$this->certificate,
			'image'=>$image,
		);
		$this->db->where('id',$this->id);
		$res = $this->db->update('emp_tbl',$data);
		if($res > 0){
			$return_data['response_status'] = 1;
			$return_data['response_msg'] = 'employee has been update';
			$return_data['return_url'] = base_url('admin/employee');
		}
		else{
			$return_data['response_status'] = 0;
			$return_data['response_msg'] = 'employee not update';
			$return_data['return_url'] = base_url('admin/edit_employee/'.$row['id']);
		}
		return $return_data;
	}
	
	public function password_change(){
    	$return_data = $this->check_password();
		if($return_data['status'] == 1){
			$data = array(
				'password'=>encrypt($this->password),
				'modify_date'=>date('Y-m-d H:i:s')
			);
			$this->db->where('id',$this->session->userdata('id'));
			$this->db->where('role','admin');
			$res = $this->db->update('user_tbl',$data);
			if($res > 0){
				$return_data['response_status'] = 1;
				$return_data['response_msg'] = 'Password has been change';
			}
			else{
				$return_data['response_status'] = 0;
				$return_data['response_msg'] = 'Password not change';				
			}
		}
		else{
			$return_data['response_status'] = 0;
			$return_data['response_msg'] = 'Password not match';
		}
		$return_data['return_url'] = base_url('admin/change-password');
		return $return_data;
    }

	public function fetch_name($emp_id){
		$this->db->where('emp_id', $emp_id);
		$this->db->order_by('name', 'ASC');
		$query = $this->db->get('emp_tbl');
		$output = '';
		foreach($query->result() as $row)
		{
		 $output .= '<option value="'.$row->name.'">'.$row->name.'</option>';
		}
		return $output;
	}
	public function get_all_leave_detail(){
		$this->db->order_by('id','DESC');
    	$row = $this->db->get('leave_manage_tbl')->result_array();
    	return $row;
	}
	public function get_management_by_id($id){
		$this->db->where('id',$id);
    	$row = $this->db->get('leave_manage_tbl')->row_array();
    	return $row;
	}
	public function edit_leave_management(){
		$row = $this->get_procurement($this->id);
		if(!empty($_FILES['file']['name'])){
			$str = random_string(5);
			$name = 'file-'.$str;
			$config['upload_path'] = './assets/backend/dist/upload/';
			$config['allowed_types'] = 'jpg|png|jpeg|doc|docx|ppt|pptx|pdf|zip|rar';
			$config['max_size'] = 10000;
			$config['file_name'] = $name;
			$this->load->library('upload',$config);
			if($this->upload->do_upload('file')){
				$file =  $this->upload->data('file_name');
			}
		}
		else{
			$file=  $row['file'];
		}
		$data = array(
			'name'=>$this->name,
			'emp_id'=>$this->emp_id,
			'leave_type'=>$this->leave_type,
			'from'=>$this->from,
			'leave_to'=>$this->leave_to,
			'days'=>$this->days,
			'replacement'=>$this->replacement,
			'approver'=>$this->approver,
			'approver_two'=>$this->approver_two,
			'file'=>$file
		);
		$this->db->where('id',$this->id);
		$id = $this->db->update('leave_manage_tbl',$data);

		if($id > 0){
			$return_data['response_status'] = 1;
			$return_data['response_msg'] = 'leave-management has been update';
			$return_data['return_url'] = base_url('admin/leave_management');
		}
		else{
			$return_data['response_status'] = 0;
			$return_data['response_msg'] = 'leave-management not update';
			$return_data['return_url'] = base_url('admin/leave_management/edit_leave_management/'.$row['id']);
		}
	return $return_data;
	}
	public function add_assets(){
		$data = array(
			'asset_type'=>$this->asset_type,
			'created_by'=>$this->created_by,
			'purchase_date'=>$this->purchase_date,
			'assign_date'=>$this->assign_date,
		);
		$this->db->insert('assets_tbl',$data);
		$id = $this->db->insert_id();
		
		if($id > 0){
			$return_data['response_status'] = 1;
			$return_data['response_msg'] = 'Assets has been add';
			$return_data['return_url'] = base_url('admin/view_my_assets');
		}
		else{
			$return_data['response_status'] = 0;
			$return_data['response_msg'] = 'Assets not add';
			$return_data['return_url'] = base_url('admin/assets');
		}
	return $return_data;
	}
	public function get_assets(){
		$row = $this->db->get('assets_tbl')->result_array();
    	return $row;
	}
	public function get_assets_by_id($id){
		$this->db->where('id',$id);
    	$row = $this->db->get('assets_tbl')->row_array();
    	return $row;
	}
	public function edit_assets(){
		$row = $this->get_assets_by_id($this->id);
		$data = array(
			'asset_type'=>$this->asset_type,
			'created_by'=>$this->created_by,
			'purchase_date'=>$this->purchase_date,
			'assign_date'=>$this->assign_date,
		);
		$this->db->where('id',$this->id);
		$id = $this->db->update('assets_tbl',$data);
		if($id > 0){
			$return_data['response_status'] = 1;
			$return_data['response_msg'] = 'Assets has been update';
			$return_data['return_url'] = base_url('admin/view_my_assets');
		}
		else{
			$return_data['response_status'] = 0;
			$return_data['response_msg'] = 'Assets not update';
			$return_data['return_url'] = base_url('admin/show_assets/'.$row['id']);
		}
	return $return_data;
	}
	public function add_procurement(){
			$str = random_string(5);
			$name = 'Procureimage-'.$str;
			$config['upload_path'] = './assets/backend/dist/img/';
			$config['allowed_types'] = 'jpg|png|jpeg';
			$config['max_size'] = 10000;			
			$config['file_name'] = $name;
			$this->load->library('upload',$config);
			if($this->upload->do_upload('featuredImage')){
				$featuredImage =  $this->upload->data('file_name');
			}
			$comment = $this->input->post('comment');
			$data = array(
				'name'=>$this->name,
				'emp_id'=>$this->emp_id,
				'item'=>$this->item,
				'quantity'=>$this->quantity,
				'unit'=>$this->unit,
				'task'=>$this->task,
				'other'=>$this->other,
				'b_category'=>$this->b_category,
				'sub_category'=>$this->sub_category,
				'approver'=>$this->approver,
				'approver_two'=>$this->approver_two,
				'approver_three'=>$this->approver_three,
				'featuredImage'=>$featuredImage,
				'comment'=>implode(",", $comment),	
			);

			$this->db->insert('procurement_tbl',$data);
			$id = $this->db->insert_id();
			
			if($id > 0){
				$return_data['response_status'] = 1;
				$return_data['response_msg'] = 'Procurement has been add';
				$return_data['return_url'] = base_url('admin/view-all-request');
			}
			else{
				$return_data['response_status'] = 0;
				$return_data['response_msg'] = 'Procurement not add';
				$return_data['return_url'] = base_url('admin/procurement');
			}
		return $return_data;
	}
	public function get_data(){
		$this->db->select('emp_tbl.emp_id,leave_manage_tbl.reason');
		$this->db->from('emp_tbl');
		$this->db->join('leave_manage_tbl', 'emp_tbl.id = leave_manage_tbl.emp_id');
		$row = $this->db->get()->result_array();
    	return $row;
	}
	public function get_all_request(){
		$row = $this->db->get('procurement_tbl')->result_array();
    	return $row;
	}
	public function get_procurement($id){
		
		$this->db->where('id',$id);
    	$row = $this->db->get('procurement_tbl')->row_array();
    	return $row;
	}
	public function edit_procurement(){
		$row = $this->get_procurement($this->id);
		if(!empty($_FILES['featuredImage']['name'])){
			$str = random_string(5);
			$name = 'procurement-'.$str;
			$config['upload_path'] = './assets/backend/dist/img/';
			$config['allowed_types'] = 'jpg|png|jpeg';
			$config['max_size'] = 10000;
			$config['file_name'] = $name;
			$this->load->library('upload',$config);
			if($this->upload->do_upload('featuredImage')){
				$featuredImage =  $this->upload->data('file_name');
			}
		}
		else{
			$image=  $row['image'];
		}
		$comment = $this->input->post('comment');
			$data = array(
				'name'=>$this->name,
				'emp_id'=>$this->emp_id,
				'item'=>$this->item,
				'quantity'=>$this->quantity,
				'unit'=>$this->unit,
				'task'=>$this->task,
				'other'=>$this->other,
				'b_category'=>$this->b_category,
				'sub_category'=>$this->sub_category,
				'approver'=>$this->approver,
				'approver_two'=>$this->approver_two,
				'approver_three'=>$this->approver_three,
				'featuredImage'=>$featuredImage,
				'comment'=>implode(",", $comment),	
		);
		$this->db->where('id',$this->id);
		$res = $this->db->update('procurement_tbl',$data);
		if($res > 0){
			$return_data['response_status'] = 1;
			$return_data['response_msg'] = 'Procurement has been update';
			$return_data['return_url'] = base_url('admin/view-all-request');
		}
		else{
			$return_data['response_status'] = 0;
			$return_data['response_msg'] = 'Procurement not update';
			$return_data['return_url'] = base_url('admin/procurement/edit_procurement/'.$row['id']);
		}
		return $return_data;
	}
	public function get_days(){
		$this->db->select('days');
		$this->db->DATEDIFF('from','leave_to');
		$thsi->db->from('leave_management_tbl');
	}
}

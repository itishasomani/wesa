<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if (!function_exists('check_login_admin')) {
    function check_login_admin() {
        $CI = get_instance();
        if ($CI->session->userdata('admin_login') != TRUE) {
            $CI->session->sess_destroy();
            redirect(base_url('login'));
        }
    }
}

if (!function_exists('encrypt')){
	function encrypt($data){
		$CI =& get_instance();
		$CI->load->library('encryption');
		return $CI->encryption->encrypt($data);		
	}
}

if (!function_exists('decrypt')){
	function decrypt($data){
		$CI =& get_instance();
		$CI->load->library('encryption');
		return $CI->encryption->decrypt($data);			
	}
}

if(!function_exists('get_user_field')){
	function get_user_field($field){
		$CI =& get_instance();
		if(isset($CI->session->userdata['userid'])){
			$CI->db->where('id',$CI->session->userdata['userid']);
			$CI->db->where('role','user');
			$row = $CI->db->get('user_tbl')->row_array();
			return $row[$field];
		};
	}
}

if(!function_exists('get_website_field')){
	function get_website_field($field){
		$CI =& get_instance();
		$row = $CI->db->get('website_settings_tbl')->row_array();
		return $row[$field];
	}
}

if(!function_exists('get_pages_content_by_id')){
	function get_pages_content_by_id($pageid){
		$CI =& get_instance();		
		$CI->db->where('id',$pageid);
		$row = $CI->db->get('pages_tbl')->row_array();
		return $row;
	}
}

if(!function_exists('preg_space')){
	function preg_space($url){
		return str_replace(' ', '-', $url);
	}
}

if(!function_exists('get_last_sort_number')){
	function get_last_sort_number(){
		$CI =& get_instance();		
		$CI->db->order_by('sort','DESC');
		$row = $CI->db->get('movies_tbl')->row_array();
		return $row['sort'] + 1;
	}
}
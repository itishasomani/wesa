<!-- Header -->
<?php $this->load->view('header'); ?>
<!-- / Header -->
    
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Edit Employee</h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active">Edit Employee</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php $get_msg = $this->message->get_message() ?>
                <?php if(!empty($get_msg)):?>
                <?php echo $get_msg;?>
                <?php endif; ?>
                <div class="row justify-content-center align-items-center">
                        <div class="col-lg-6">
                            <div class="card card-primary">
                                <!-- form start -->
                                <form  method="post" action="<?php echo base_url('admin/employee-edit');?>" id="editEmployee" enctype="multipart/form-data">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="exampleInputName">Name</label>
                                            <input type="text" id="exampleInputName" name="name" class="form-control" placeholder="Name" value="<?php echo $employee['name'];?>">
                                            <input type="hidden" name="id" value="<?php echo $employee['id'];?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputNameEmpID">Employee ID</label>
                                            <input type="text" id="exampleInputNameEmpID" name="emp_id" class="form-control" placeholder="Employee ID" value="<?php echo $employee['emp_id'];?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputUsername">Username</label>
                                            <input type="text" id="exampleInputUsername" name="username" class="form-control" placeholder="Username" value="<?php echo $employee['username'];?>">
                                        </div>
                                        <!-- <div class="form-group">
                                            <label for="exampleInputPassword">Password</label>
                                            <input type="password" id="exampleInputPassword" name="password" class="form-control" placeholder="Password" value="<?php echo $employee['password'];?>">
                                        </div> -->
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Email ID</label>
                                            <input type="email" id="exampleInputEmail" name="email_id" class="form-control" placeholder="Email ID" value="<?php echo $employee['email_id'];?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Phone no</label>
                                            <input type="number" id="exampleInputEmail" name="phone" class="form-control" placeholder="phone" value="<?php echo $employee['phone'];?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPosition">Position</label>
                                            <select id="exampleInputPosition"  name="position" class="form-control" >
                                                <option value="<?= $employee['position']?>"><?php echo $employee['position'];?></option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Department</label>
                                            <input type="text" id="exampleInputEmail" name="department" class="form-control" placeholder="Department" value="<?php echo $employee['department'];?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Education</label>
                                            <input type="text" id="exampleInputEmail" name="education" class="form-control" placeholder="education" value="<?php echo $employee['education'];?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Training</label>
                                            <input type="text" id="exampleInputEmail" name="training" class="form-control" placeholder="training" value="<?php echo $employee['training'];?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Certificate</label>
                                            <input type="text" id="exampleInputEmail" name="certificate" class="form-control" placeholder="certificate" value="<?php echo $employee['certificate'];?>" >
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputImage">Image</label>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input"  name="image" id="exampleInputImage" accept="image/*">
                                                    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.card-body -->
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                </div>
            </div>
        </section>
    </div>

<!-- Footer -->
<?php $this->load->view('footer'); ?>
<!-- / Footer -->

<script>
    $("#editEmployee").validate({
        errorClass: 'error',
        errorElement: 'span',
        successClass: 'success',
        rules:{            
            name: 'required',
            emp_id: 'required',
            username: 'required',
            password: 'required',
            email_id: 'required',
            position: 'required',
        }
    });   
</script>
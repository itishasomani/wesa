<!-- Header -->
<?php $this->load->view('header'); ?>
<!-- / Header -->

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">New Request</h1>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                                <li class="breadcrumb-item active">New Request</li>
                            </ol>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
            <!-- Main content -->
            <section class="content">
            <div class="container-fluid">
                <?php $get_msg = $this->message->get_message() ?>
                <?php if(!empty($get_msg)):?>
                <?php echo $get_msg;?>
                <?php endif; ?>
                <div class="row justify-content-center align-items-center">
                        <div class="col-lg-6">
                            <div class="card card-primary">
                                <!-- form start -->
                                <form method="post" action="<?php echo base_url('admin/add_procurement');?>" id="Procurement" enctype="multipart/form-data">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="exampleInputName">Name</label>
                                            <select name="name" class="form-control" id="name">
                                                <option value="">Name</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputNameEmpID">Employee ID</label>
                                            <select name="emp_id" id="EmpID" class="form-control input-lg">
                                                <option value="">Employee Id</option>
                                                    <?php foreach($employee as $emp):?>
                                                        <option value="<?=$emp['emp_id']?>"><?=$emp['emp_id']?></option>
                                                    <?php endforeach?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputItem">Item</label>
                                            <input type="text" id="exampleInputOther" name="item" class="form-control" placeholder="Item">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputQuantity">Quantity</label>
                                            <select name="quantity" id="quantity" class="form-control input-lg">
                                                <option value="">quantity</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputUnit">Unit</label>
                                            <select name="unit" id="unit" class="form-control input-lg">
                                                <option value="">unit</option>
                                                <option value="box">Box</option>
                                                <option value="item">item</option>
                                                <option value="pallet">pallet</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputTask">Task</label>
                                            <select name="task" id="task" class="form-control input-lg">
                                                <option value="">task</option>
                                                <option value="wh">WH</option>
                                                <option value="Project">Project</option>
                                                <option value="office">Office</option>
                                                <option value="other">Other</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputOther">Others</label>
                                            <textarea id="exampleInputother" name="other" cols="30" rows="5" class="form-control"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputTask">Budget Category</label>
                                            <select name="b_category" id="b_category" class="form-control input-lg">
                                                <option value=""></option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputTask">Budget Sub-Category</label>
                                            <select name="sub_category" id="sub_category" class="form-control input-lg">
                                                <option value=""></option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputApprover">Approver 1</label>
                                            <select name="approver" id="approver" class="form-control input-lg">
                                                <option value=""></option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <label for="exampleInputApprover">Approver 2</label>
                                            <select name="approver_two" id="approver_two" class="form-control input-lg">
                                                <option value=""></option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <label for="exampleInputApprover">Approver 3</label>
                                            <select name="approver_three" id="approver_three" class="form-control input-lg">
                                                <option value=""></option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputAttachment">Attachment</label>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" name="featuredImage" class="custom-file-input" id="exampleInputAttachment">
                                                    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputComment">Comments</label>
                                            <div class="form-check ">
                                                <input class="form-check-input" type="checkbox" name="comment[]" value="plan" id="inlineRadio1" checked>
                                                <label class="form-check-label" for="inlineRadio1">Dispatch plan</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="comment[]" value="request" id="inlineRadio1" checked>
                                                <label class="form-check-label" for="inlineRadio1">Company Requests</label>
                                            </div>
                                            <div class="form-check ">
                                                <input class="form-check-input" type="checkbox" name="comment[]" value="customerSpec" id="inlineRadio1" checked>
                                                <label class="form-check-label" for="inlineRadio1">Customer Spec</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="comment[]" value="requirement" id="inlineRadio1" checked>
                                                <label class="form-check-label" for="inlineRadio1">Requirements</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="comment[]" value="regulatory" id="inlineRadio1" checked>
                                                <label class="form-check-label" for="inlineRadio1">Regulatory and Standard</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="comment[]" value="cost_sheet" id="inlineRadio1" checked>
                                                <label class="form-check-label" for="inlineRadio1">Cost sheet</label>
                                            </div>
                                            <div class="form-check ">
                                                <input class="form-check-input" type="checkbox" name="comment[]" value="po" id="inlineRadio1" checked>
                                                <label class="form-check-label" for="inlineRadio1">PO</label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="comment[]" value="contract_plan" id="inlineRadio1" checked>
                                                <label class="form-check-label" for="inlineRadio1">Contract plan</label>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.card-body -->
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                        <!-- <button type="submit" class="btn btn-outline-primary ml-2">Send</button> -->
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
            </div>
        </section>
    </div>

<!-- Footer -->
<?php $this->load->view('footer'); ?>
<!-- / Footer -->

<script>
    $("#Procurement").validate({
        errorClass: 'error',
        errorElement: 'span',
        successClass: 'success',
        rules:{            
            name: 'required',
            reason: 'required',
            detail: 'required',
            other_reason: 'required',
            days: 'required',
            // approver: 'required',
            featuredImage: 'required'
        }
    });  
$(document).ready(function(){
    $('#EmpID').change(function(){
        var emp_id = $('#EmpID').val();
        if(emp_id != '')
        {
            $.ajax({
                url:"<?php echo base_url(); ?>admin/fetch_name",
                method:"POST",
                data:{emp_id:emp_id},
                success:function(data)
                {
                    $('#name').html(data);
                }
            });
        }
        else
        {
            $('#name').html('<option value="">Name</option>');
        }
    });
}); 
</script>
<!-- Header -->
<?php $this->load->view('header'); ?>
<!-- / Header -->

 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0">Show Procurement</h1>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-6">
                            <ol class="breadcrumb float-sm-right">
                                <li class="breadcrumb-item"><a href="../index.php">Home</a></li>
                                <li class="breadcrumb-item active">Show Procurement</li>
                            </ol>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /.content-header -->
            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <?php $get_msg = $this->message->get_message() ?>
                    <?php if(!empty($get_msg)):?>
                    <?php echo $get_msg;?>
                    <?php endif; ?>
                    <div class="row d-flex justify-content-center align-items-center">
                        <div class="col-lg-10 pb-5">
                            <div class="card-body bg-white rounded shadow-sm">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Name</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary"><?php echo $procurement['name']?></div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Employee ID</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary"><?php echo $procurement['emp_id']?></div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Reason</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary"><?php echo $procurement['reason']?></div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Details</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary"><?php echo $procurement['detail']?></div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">If Other Please Specify</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary"><?php echo $procurement['other_reason']?></div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Total Days</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary"><?php echo $procurement['days']?></div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Approver/Supervisor</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary"><?php echo $procurement['approver']?></div>
                                </div>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <h6 class="mb-0">Attachment</h6>
                                    </div>
                                    <div class="col-sm-9 text-secondary">
                                        <img src="<?php echo base_url('assets/backend/dist/img/')?><?php echo $procurement['featuredImage']?>" style="width: 70px;" class="border rounded-pill" alt="">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
</div>
<!-- Footer -->
<?php $this->load->view('footer'); ?>
<!-- / Footer -->
<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo base_url('admin');?>" class="brand-link">
        <img src="<?php echo base_url('assets/backend/dist/img/AdminLTELogo.png')?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3">
        <span class="brand-text font-weight-light">Wesa</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
    <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">               
                <li class="nav-item <?php if($active == 'dashboard'){echo 'menu-open';}?>">
                    <a href="<?php echo base_url('admin');?>" class="nav-link <?php if($active == 'dashboard'){echo 'active';}?>">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>
                            Dashboard
                        </p>
                    </a>
                </li>
                <li class="nav-item <?php if($active == 'leave_management'){echo 'menu-open';}?>">
                    <a href="<?php echo base_url('admin/leave-management');?>" class="nav-link <?php if($active == 'leave_management'){echo 'active';}?>">
                        <i class="nav-icon fas fa-tasks"></i>
                        <p>                                
                        Leave Management
                        </p>
                    </a>
                </li>
                <li class="nav-item <?php if($active == 'procurement' || $active == 'view_all_request'){echo 'menu-open';}?>">
                    <a href="#" class="nav-link <?php if($active == 'procurement' || $active == 'view_all_request'){echo 'active';}?>">
                        <i class="nav-icon fas fa-info-circle"></i>
                            <p>
                                Procurement
                                <i class="fas fa-angle-left right"></i>
                            </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo base_url('admin/procurement');?>" class="nav-link <?php if($active == 'procurement'){echo 'active';}?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>New Request</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('admin/view-all-request');?>" class="nav-link <?php if($active == 'view_all_request'){echo 'active';}?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>View All Requests</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item <?php if($active == 'assets' || $active == 'view_my_assets'){echo 'menu-open';}?>">
                    <a href="#" class="nav-link <?php if($active == 'assets' || $active == 'view_my_assets'){echo 'active';}?>">
                        <i class="nav-icon fas fa-info-circle"></i>
                        <p>
                        Assets
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo base_url('admin/assets');?>" class="nav-link  <?php if($active == 'assets'){echo 'active';}?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Create Assets</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo base_url('admin/view_my_assets');?>" class="nav-link  <?php if($active == 'view_my_assets'){echo 'active';}?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>View Assets</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item <?php if($active == 'employee'){echo 'menu-open';}?>">
                    <a href="<?php echo base_url('admin/employee');?>" class="nav-link <?php if($active == 'employee'){echo 'active';}?>">
                        <i class="nav-icon fas fa-users"></i>
                        <p>Employee</p>
                    </a>
                </li>
                <li class="nav-item <?php if($active == 'profile'|| $active == 'change_password'){echo 'menu-open';}?>">
                    <a href="#" class="nav-link <?php if($active == 'profile' || $active == 'change_password'){echo 'active';}?>">
                        <i class="nav-icon fas fa-user-shield"></i>
                        <p>
                            Admin
                            <i class="fas fa-angle-left right"></i>
                            </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo base_url('admin/change-password');?>" class="nav-link <?php if($active == 'change_password'){echo 'active';}?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Change Password</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="<?php echo base_url('login/logout');?>" class="nav-link">
                        <i class="nav-icon fas fa-sign-out-alt"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<!-- Header -->
<?php $this->load->view('header'); ?>
<!-- / Header -->
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper" id="leave_management">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Vacation/Medical Leave</h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active">Vacation/Medical Leave</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php $get_msg = $this->message->get_message() ?>
                <?php if(!empty($get_msg)):?>
                <?php echo $get_msg;?>
                <?php endif; ?>
                <div class="row justify-content-around">
                        <div class="col-lg-6">
                            <div class="card card-primary">
                                <!-- form start -->
                                <form method="post" action="<?php echo base_url('admin/add-leave-management');?>" id="addLeaveManagement" enctype="multipart/form-data">
                                    <div class="card-body">
                                    
                                        <div class="form-group">
                                        <label for="exampleInputName">Name</label>
                                            <select name="name" class="form-control" id="name">
                                                <option value="">Name</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                        <label for="exampleInputNameEmpID">Employee ID</label>
                                        <select name="emp_id" id="EmpID" class="form-control input-lg">
                                            <option value="">Employee Id</option>
                                                <?php foreach($employee as $emp):?>
                                                    <option value="<?=$emp['id']?>"><?=$emp['id']?></option>
                                                <?php endforeach?>
                                        </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputLeaveType">Leave Type</label>
                                            <div class="form-check form-check-inline ml-3">
                                                <input class="form-check-input" type="radio" name="leave_type" value="annual" id="inlineRadio1">
                                                <label class="form-check-label" for="inlineRadio1">Annual</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="leave_type" value="no-paid" id="inlineRadio2">
                                                <label class="form-check-label" for="inlineRadio2">No paid</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="leave_type" value="occasion" id="inlineRadio2">
                                                <label class="form-check-label" for="inlineRadio2">Occasion</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="leave_type" value="medical" id="inlineRadio2">
                                                <label class="form-check-label" for="inlineRadio2">Medical</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="leave_type" value="other" id="inlineRadio2">
                                                <label class="form-check-label" for="inlineRadio2">Other</label>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6">
                                                <label for="exampleInputLeaveDate">Leave From</label>
                                                <input type="date" id="datefrom" name="from" class="form-control datepick" onchange="cal()" placeholder="">
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="exampleInputLeaveDate">Leave To</label>
                                                <input type="date" id="dateto" name="leave_to" class="form-control datepick" onchange="cal()" placeholder="">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputTotalDays">Total Days</label>
                                            <input type="number" id="days" name="days" class="form-control" placeholder="0 Days">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputReplacement">Replacement</label>
                                            <select id="exampleInputReplacement" name="replacement" class="form-control">
                                                <option value="replacement">Replacement</option>
                                                <?php foreach($employee as $emp):?>
                                                    <option value="<?=$emp['name']?>"><?=$emp['name']?></option>
                                                <?php endforeach?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputApprover">Approver 1</label>
                                            <select id="exampleInputApprover" name="approver" class="form-control">
                                                <option value="approver">Approver</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputApprover">Approver 2</label>
                                            <select id="exampleInputApprover" name="approver_two" class="form-control">
                                                <option value="approver">Approver</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputImage">Attachment</label>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input"  name="file" id="exampleInputImage">
                                                    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.card-body -->
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                        <!-- <button type="text" class="btn btn-primary">Send</button> -->
                                    </div>
                                </form>
                                <div class="card-footer" style="text-align:end;">
                                    <a href="" style="margin-top: -110px;" id="btn" class="btn btn-primary">Send</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card p-3">
                                <h4>Leave Policy</h4>
                                <p>1. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores, aliquid.</p>
                                <p>2. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores, aliquid.</p>
                                <p>3. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores, aliquid.</p>
                            </div>
                        </div>
                </div>
            </div>
        </section>
    <!-- /.content-header -->
    </div>
<!-- Footer -->
<?php $this->load->view('footer'); ?>
<!-- / Footer -->

<script>
$(document).ready(function(){
    $('#EmpID').change(function(){
        var emp_id = $('#EmpID').val();
        if(emp_id != '')
        {
            $.ajax({
                url:"<?php echo base_url(); ?>admin/fetch_name",
                method:"POST",
                data:{emp_id:emp_id},
                success:function(data)
                {
                    $('#name').html(data);
                }
            });
        }
        else
        {
            $('#name').html('<option value="">Name</option>');
        }
    });
});

function GetDays(){
    var fromdt = new Date(document.getElementById("datefrom").value);
    var todt = new Date(document.getElementById("dateto").value);
    return parseInt((todt -fromdt ) / (24 * 3600 * 1000));
}
function cal(){
    if(document.getElementById("datefrom")){
    document.getElementById("days").value=GetDays();
    }  
}
</script>
<script>
    $("#addLeaveManagement").validate({
        errorClass: 'error',
        errorElement: 'span',
        successClass: 'success',
        rules:{            
            name: 'required',
            emp_id:'required',
            leave_date: 'required',
            replacement:'required',
            days: 'required',
            file: 'required',
        }
    });   
</script>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('login_model');
	}
	
	public function index()
	{
		$this->load->view('login');
	}

	public function do_login(){
        $this->login_model->email = $this->input->post('email');
        $this->login_model->password = $this->input->post('password');;
        $return_data = $this->login_model->login_process();
        $this->message->set_message($return_data['response_msg'],$return_data['response_status']);
        redirect($return_data['return_url']);
    }
    
    function logout(){
        $userdata = array('id'=>'','name'=>'','email'=>'','role'=>'','admin_login'=>'');
        $this->session->set_userdata($userdata);
        $this->message->set_message('Logout Successfully',1);
        redirect(base_url());
    }
}

/* End of file Login.php */
/* Location: application/controllers/Login.php */
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employee extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		check_login_admin();
		$this->load->model('common_model');
	}
    public function index()
	{	
		$data['active'] = 'employee';
		$data['employees'] = $this->common_model->get_employee();
		$this->load->view('employee/index',$data);
	}
	public function add_employee(){
		$data['active'] = 'add_employee';
		$this->load->view('employee/add_employee',$data);
	}
    public function edit_employee($id){
        $data['active'] = 'edit_employee';
        $data['employee'] = $this->common_model->get_employee_by_id($id);
		$this->load->view('employee/edit_employee',$data);
    }
    public function save_employee(){
        $this->common_model->name = $this->input->post('name');
        $this->common_model->emp_id = $this->input->post('emp_id');
        $this->common_model->username = $this->input->post('username');
        $this->common_model->password = sha1($this->input->post('password'));
        $this->common_model->email_id = $this->input->post('email_id');
        $this->common_model->phone = $this->input->post('phone');
        $this->common_model->position = $this->input->post('position');
        $this->common_model->department = $this->input->post('department');
        $this->common_model->education = $this->input->post('education');
        $this->common_model->training = $this->input->post('training');
        $this->common_model->certificate = $this->input->post('certificate');
        $this->common_model->image = $_FILES['image']['name'];
        $return_data = $this->common_model->add_employee();
		$this->message->set_message($return_data['response_msg'],$return_data['response_status']);
		redirect($return_data['return_url']);
    }
    public function employee_edit(){
        $this->common_model->id = $this->input->post('id');
        $this->common_model->name = $this->input->post('name');
        $this->common_model->emp_id = $this->input->post('emp_id');
        $this->common_model->phone = $this->input->post('phone');
        $this->common_model->username = $this->input->post('username');
        $this->common_model->password = sha1($this->input->post('password'));
        $this->common_model->email_id = $this->input->post('email_id');
        $this->common_model->position = $this->input->post('position');
        $this->common_model->department = $this->input->post('department');
        $this->common_model->education = $this->input->post('education');
        $this->common_model->training = $this->input->post('training');
        $this->common_model->certificate = $this->input->post('certificate');
        $this->common_model->image = $_FILES['image']['name'];
        $return_data = $this->common_model->edit_employee();
		$this->message->set_message($return_data['response_msg'],$return_data['response_status']);
		redirect($return_data['return_url']);
    }
    public function delete_employee($id){
        $row = $this->common_model->get_employee_by_id($id);
		unlink(realpath('assets/backend/dist/img/'.$row['image']));		
		$this->db->where('id',$id);
		$this->db->delete('emp_tbl');
		$this->message->set_message('employee has been delete',1);
        redirect(base_url('admin/employee'));
    }
}
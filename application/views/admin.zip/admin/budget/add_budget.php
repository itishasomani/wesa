<!-- Header -->
<?php $this->load->view('header'); ?>
<!-- / Header -->
 
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Add Budget</h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active">Add Budget</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php $get_msg = $this->message->get_message() ?>
                <?php if(!empty($get_msg)):?>
                <?php echo $get_msg;?>
                <?php endif; ?>
                <div class="row justify-content-center align-items-center">
                        <div class="col-lg-6">
                            <div class="card card-primary">
                                <!-- form start -->
                                <form  method="post" action="<?php echo base_url('admin/save_budget');?>" id="addBudget" enctype="multipart/form-data">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label for="exampleInputNameEmpID">Task</label>
                                            <select name="task" id="task" class="form-control input-lg">
                                                <option value="task">Task</option>
                                                    <?php foreach($tasks as $task):?>
                                                        <option value="<?=$task['task_name']?>"><?=$task['task_name']?></option>
                                                    <?php  endforeach?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputCategory">Category</label>
                                            <input type="text" id="exampleInputCategory" name="category" class="form-control" placeholder="Category">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputSubCategory">Sub Category</label>
                                            <input type="text" id="exampleInputSubCategory" name="sub_category" class="form-control" placeholder="SubCategory">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputTotalAmount">Total Amount</label>
                                            <input type="text" id="exampleInputTotalAmount" name="amount" class="form-control" placeholder="Total Amount">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputUploadeby">Uploade by</label>
                                            <select name="upload_by" class="form-control" id="upload_by">
                                                <option value="">Employees</option>
                                                <?php foreach($employee as $emp):?>
                                                    <option value="<?=$emp['name']?>"><?=$emp['name']?></option>
                                                <?php endforeach?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputTemplate">Upload template</label>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input" name="template" id="exampleInputTemplate" accept="image/*">
                                                    <label class="custom-file-label" for="exampleInputFile">upload</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.card-body -->
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
            </div>
        </section>
    </div>

<!-- Footer -->
<?php $this->load->view('footer'); ?>
<!-- / Footer -->

<script>
    $("#addBudget").validate({
        errorClass: 'error',
        errorElement: 'span',
        successClass: 'success',
        rules:{            
            task: 'required',
            template: 'required',
        }
    });
</script>
<!-- Header -->
<?php $this->load->view('header'); ?>
<!-- / Header -->
    
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Employee</h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active">Employee</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php $get_msg = $this->message->get_message() ?>
                <?php if(!empty($get_msg)):?>
                <?php echo $get_msg;?>
                <?php endif; ?>
                <div class="d-flex justify-content-end mb-2">
                    <a href="<?php echo base_url('admin/add-employee'); ?>" class="btn btn-dark">Add</a>
                </div>

                <div class="row mt-5">
                
                        <?php foreach($employees as $employee): ?>
                                <div class="col-sm-6 col-md-6 mb-1">
                                <?php
        
                                    $currentDate = date('Y-m-d');
                                    foreach($leave_detail as $date) {
                                        $from_date = $date['from'];
                                        $to_date = $date['leave_to'];
                                    
                                    $email = $date['email'];
                                    $currentDate = date('Y-m-d', strtotime($currentDate));
                                    $startDate = date('Y-m-d', strtotime($from_date));
                                    $endDate = date('Y-m-d', strtotime($to_date));
                                    if ($currentDate > $startDate && $currentDate < $endDate && $email == $employee['email'] ){
                                        echo "<a class='vacation_tag'><span>V</span></a>";
                                    }
                                    
                                }
                            ?>
                            <div class="info-box p-3">
                                <span>
                                    <img src="<?php echo base_url('assets/backend/dist/img/')?><?php echo $employee['image'];?>" style="width: 100px;" class="border rounded-circle" alt="">
                                </span>
                                <div class="info-box-content pl-3">
                                    <h6 class="text p-1"><span class="text-bold">NAME :</span> <?php echo $employee['name'];?></h6>
                                    <h6 class="text p-1"><span class="text-bold">POSITION :</span> <?php echo $employee['position'];?></h6>
                                    <h6 class="text p-1"><span class="text-bold">DEPARTMENT : </span><?php echo $employee['department'];?></h6>
                                    <h6 class="text p-1"><span class="text-bold">EMAIL :</span> <?php echo $employee['email'];?></h6>
                                    <h6 class="text p-1"><span class="text-bold">PHONE NO : </span><?php echo $employee['phone'];?></h6>
                                </div>
                                <div class="info-box-icon_">
                                    <a href="<?php echo base_url('admin/employee/edit_employee/'.$employee['id'])?>">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="<?php echo base_url('admin/employee/delete_employee/'.$employee['id'])?>"><i class="fa fa-trash"></i></a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                </div>
            </div>
        </section>
    </div>

<!-- Footer -->
<?php $this->load->view('footer'); ?>
<!-- / Footer -->


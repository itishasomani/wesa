<!-- Header -->
<?php $this->load->view('header'); ?>
<!-- / Header -->
 <style>
 #project-manager{
     display:none;
 }
 </style>   
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Add Employee</h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active">Add Employee</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php $get_msg = $this->message->get_message() ?>
                <?php if(!empty($get_msg)):?>
                <?php echo $get_msg;?>
                <?php endif; ?>
                <div class="row justify-content-center align-items-center">
                        <div class="col-lg-6">
                            <div class="card card-primary">
                                <!-- form start -->
                                <form  method="post" action="<?php echo base_url('admin/add_employee');?>" id="addEmployee" enctype="multipart/form-data">
                                    <div class="card-body">
                                    <input type="hidden" id="exampleInputName" name="role" value="employee" class="form-control" placeholder="Name">
                                        <div class="form-group">
                                            <label for="exampleInputName">Name</label>
                                            <input type="text" id="exampleInputName" name="name" class="form-control" placeholder="Name">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputNameEmpID">MY Employee ID</label>
                                            <input type="text" id="exampleInputNameEmpID" name="emp_id" class="form-control" placeholder="Employee ID">
                                        </div>
                                        <div class="form-group">
                                        <label for="exampleInputNameEmpID">Employee Type</label>
                                        <select name="emp_type" id="EmpType" class="form-control input-lg">
                                            <option value="">Employee Type</option>
                                                <?php foreach($emp_type as $type):?>
                                                    <option value="<?=$type['emp_type']?>"><?=$type['emp_type']?></option>
                                                <?php  endforeach?>
                                        </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="exampleInputUsername">Username</label>
                                            <input type="text" id="exampleInputUsername" name="username" class="form-control" placeholder="Username">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword">Password</label>
                                            <input type="password" id="exampleInputPassword" name="password" class="form-control" placeholder="Password">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Email ID</label>
                                            <input type="email" id="exampleInputEmail" name="email" class="form-control" placeholder="Email ID">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Phone no</label>
                                            <input type="number" id="exampleInputEmail" name="phone" class="form-control" placeholder="phone">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPosition">Position</label>
                                            <select id="exampleInputPosition" name="position" class="form-control" >
                                                <option value="employee">Employee</option>
                                                <option value="staff">Staff</option>
                                                <option value="hr">HR</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Department</label>
                                            <input type="text" id="exampleInputEmail" name="department" class="form-control" placeholder="Department">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Education</label>
                                            <input type="text" id="exampleInputEmail" name="education" class="form-control" placeholder="education">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Training</label>
                                            <input type="text" id="exampleInputEmail" name="training" class="form-control" placeholder="training">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail">Certificate</label>
                                            <input type="text" id="exampleInputEmail" name="certificate" class="form-control" placeholder="certificate">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputImage">Image</label>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input"  name="image" id="exampleInputImage" accept="image/*">
                                                    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.card-body -->
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
            </div>
        </section>
    </div>

<!-- Footer -->
<?php $this->load->view('footer'); ?>
<!-- / Footer -->

<script>
    $("#addEmployee").validate({
        errorClass: 'error',
        errorElement: 'span',
        successClass: 'success',
        rules:{            
            name: 'required',
            emp_id: 'required',
            emp_type:'required',
            username: 'required',
            password: 'required',
            email_id: 'required',
            phone:'required',
            position: 'required',
            department:'required',
            education:'required',
            training:'required',
            certificate:'required',
            image:'required'
        }
    });
    // $(document).ready(function(){
    //     $("select").change(function(){
    //         $( "select option:selected").each(function(){
    //             if($(this).attr("value")=="Project Manager"){
    //                 $("#project-manager").show();
    //             }
    //             if($(this).attr("value")==""){
    //                 $("#project-manager").show();
    //             }
    //         });
    //     }).change();
    // }); 
</script>
<!-- Header -->
<?php $this->load->view('header'); ?>
<!-- / Header -->
    
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Edit Vacation/Medical Leave</h1>
                    </div>
                    <!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active">Edit Vacation/Medical Leave</li>
                        </ol>
                    </div>
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                <?php $get_msg = $this->message->get_message() ?>
                <?php if(!empty($get_msg)):?>
                <?php echo $get_msg;?>
                <?php endif; ?>
                <div class="row justify-content-around">
                        <div class="col-lg-6">
                            <div class="card card-primary">
                                <!-- form start -->
                                <form method="post" action="<?php echo base_url('admin/leave-management-edit');?>" id="editLeavemanagement" enctype="multipart/form-data">
                                    <div class="card-body">
                                        <div class="form-group">
                                        <input type="hidden" id="exampleInputName" name="email" value="<?php echo isset($_SESSION['email']) ? $_SESSION['email'] : ''; ?>" class="form-control" placeholder="Email">
                                        <input type="hidden" id="exampleInputName" name="role" value="employee" class="form-control" placeholder="Role">
                                            <label for="exampleInputName">Name</label>
                                            <input type="hidden" name="id" value="<?php echo $leave_management['id'];?>">
                                            <select name="name" class="form-control" id="name">
                                                <option value="<?php echo $leave_management['name'];?>"><?php echo $leave_management['name'];?></option>
                                                <?php foreach($employee as $emp):?>
                                                    <option value="<?=$emp['name']?>"><?=$emp['name']?></option>
                                                <?php endforeach?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputNameEmpID">Employee ID</label>
                                            <select name="emp_id" id="EmpID" class="form-control input-lg" readonly>
                                                <option value="<?php echo $leave_management['emp_id'];?>"><?php echo $leave_management['emp_id'];?></option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputLeaveType">Leave Type </label>
                                            <?php $type = $leave_management['leave_type'];?>
                                            <div class="form-check form-check-inline ">
                                                <input class="form-check-input" type="radio" name="leave_type" value="Annual" <?php echo ($type=='Annual')?'checked':'' ;?> id="inlineRadio1">
                                                <label class="form-check-label" for="inlineRadio1">Annual</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="leave_type" value="Nopaid" <?php echo ($type=='Nopaid')?'checked':'' ;?> id="inlineRadio2">
                                                <label class="form-check-label" for="inlineRadio2">No paid</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="leave_type" value="Occasion" <?php echo ($type=='Occasion')?'checked':'' ;?> id="inlineRadio2">
                                                <label class="form-check-label" for="inlineRadio2">Occasion</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="leave_type" value="Medical" <?php echo ($type=='Medical')?'checked':'' ;?> id="inlineRadio2">
                                                <label class="form-check-label" for="inlineRadio2">Medical</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="leave_type" value="Business Trip" <?php echo ($type=='Business Trip')?'checked':'' ;?> id="inlineRadio2">
                                                <label class="form-check-label" for="inlineRadio2">Business Trip</label>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-sm-6">
                                                <label for="exampleInputLeaveDate">Leave From</label>
                                                <input type="date" id="datefrom" name="from" class="form-control datepick" onchange="cal()" value="<?php echo $leave_management['from'];?>" placeholder="">
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="exampleInputLeaveDate">Leave To</label>
                                                <input type="date" id="dateto" name="leave_to" class="form-control datepick" onchange="cal()" value="<?php echo $leave_management['leave_to'];?>" placeholder="">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputTotalDays">Total Days</label>
                                            <input type="number" id="days" name="days" class="form-control" value="<?php echo $leave_management['days'];?>" placeholder="0 Days" readonly>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputDateBackToWork">Date Back To Work</label>
                                            <input type="date" id="dateBack" name="back_to" class="form-control" value="<?php echo $leave_management['back_to'];?>" placeholder="Date Back To Work">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputReplacement">Replacement</label>
                                            <select id="exampleInputReplacement" name="replacement" class="form-control">
                                            <option value="<?= $leave_management['replacement']?>"> <?= $leave_management['replacement']?></option>
                                            <?php foreach($employee as $emp):?>
                                                    <option value="<?=$emp['name']?>"><?=$emp['name']?></option>
                                                <?php endforeach?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputApprover">Approver 1</label>
                                            <select id="exampleInputApprover" name="approver" class="form-control">
                                                <option value="Approver">Approver</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputApprover">Approver 2</label>
                                            <select id="exampleInputApprover" name="approver_two" class="form-control">
                                            <option value="Director">Director</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputApprover">HR Manager</label>
                                            <select id="exampleInputApprover" name="manager" class="form-control">
                                            <option value="HR Manager">HR Manager</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputComment">Comments</label>
                                            <textarea id="exampleInputComment" name="comment" cols="30" rows="5" class="form-control"><?php echo $leave_management['comment'];?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputImage">Attachment</label>
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input"  name="file" id="exampleInputImage">
                                                    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- /.card-body -->
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="card p-3">
                                <h4>Leave Policy</h4>
                                <p>1. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores, aliquid.</p>
                                <p>2. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores, aliquid.</p>
                                <p>3. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Asperiores, aliquid.</p>
                            </div>
                        </div>
                </div>
            </div>
        </section>
    <!-- /.content-header -->
    </div>

<!-- Footer -->
<?php $this->load->view('footer'); ?>
<!-- / Footer -->

<script>
$(document).ready(function(){
    $('#name').change(function(){
        var name = $('#name').val();
        if(name != '')
        {
            $.ajax({
                url:"<?php echo base_url(); ?>admin/fetch_name",
                method:"POST",
                data:{name:name},
                success:function(data)
                {
                    console.log(data);
                    $('#EmpID').html(data);
                }
            });
        }
        else
        {
            $('#EmpID').html('<option value="">Employee Id</option>');
        }
    });
});
function GetDays(){
    var fromdt = new Date(document.getElementById("datefrom").value);
    var todt = new Date(document.getElementById("dateto").value);
    return parseInt((todt -fromdt ) / (24 * 3600 * 1000));
}
function cal(){
    if(document.getElementById("datefrom")){
    document.getElementById("days").value=GetDays();
    }  
}
$("#editLeavemanagement").validate({
        errorClass: 'error',
        errorElement: 'span',
        successClass: 'success',
        rules:{            
            name: 'required',
            from: 'required',
            leave_to:'required',
            back_to:'required',
            replacement:'required',
            days: 'required',
        }
    });   
</script>
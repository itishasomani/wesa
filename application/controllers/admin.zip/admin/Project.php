<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Project extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		check_login_admin();
		$this->load->model('common_model');
	}
	public function index()
	{	
		$data['active'] = 'project';
        $data['projects'] = $this->common_model->get_project();
		$this->load->view('admin/project/index',$data);
	}
    public function add_project()
	{	
		$data['active'] = 'project';
        $data['employee'] = $this->common_model->get_employee();
		$this->load->view('admin/project/add_project',$data);
	}
    public function save_project(){
        $this->common_model->task_name = $this->input->post('task_name');
        $this->common_model->address_1 = $this->input->post('address_1');
        $this->common_model->address_2 = $this->input->post('address_2');
        $this->common_model->address_3 = $this->input->post('address_3');
        $this->common_model->emp_name = $this->input->post('emp_name');
        $return_data = $this->common_model->add_project();
		redirect($return_data['return_url']);
    }
    public function edit_project($id){
        $data['active'] = 'edit_project';
        $data['employee'] = $this->common_model->get_employee();
        $data['project'] = $this->common_model->get_project_by_id($id);
		$this->load->view('admin/project/edit_project',$data);
    }
    public function project_edit(){
        $this->common_model->id = $this->input->post('id');
        $this->common_model->task_name = $this->input->post('task_name');
        $this->common_model->address_1 = $this->input->post('address_1');
        $this->common_model->address_2 = $this->input->post('address_2');
        $this->common_model->address_3 = $this->input->post('address_3');
        $this->common_model->emp_name = $this->input->post('emp_name');
        $return_data = $this->common_model->edit_project();
		// $this->message->set_message($return_data['response_msg'],$return_data['response_status']);
		redirect($return_data['return_url']);
    }
    public function delete_project($id){
        $row = $this->common_model->get_project_by_id($id);		
		$this->db->where('id',$id);
		$this->db->delete('project');
        redirect(base_url('admin/project'));
    }
}
?>
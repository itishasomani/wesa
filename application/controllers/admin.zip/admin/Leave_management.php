<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Leave_management extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		check_login_admin();
		$this->load->helper('download');
		$this->load->model('common_model');
	}
    public function index()
	{	
		$data['active'] = 'leave_management';
		$data['leave_detail'] = $this->common_model->get_all_leave_detail();
		$this->load->view('admin/leave_management/index',$data);
	}
	public function approve_request(){
		$data['active'] = 'approve_request';
		// $data['leave_detail'] = $this->common_model->get_all_leave_detail();
		$this->load->view('admin/leave_management/approve_request',$data);
	}
	public function add_leave_management(){
		$data['active'] = 'add_leave_management';
		$data['employee'] = $this->common_model->get_employee();
		$this->load->view('admin/leave_management/add_leave_management',$data);
	}
	public function save_leave_management(){
		$this->common_model->role = $this->input->post('role');
		$this->common_model->email = $this->input->post('email');
		$this->common_model->name = $this->input->post('name');
		$this->common_model->emp_id = $this->input->post('emp_id');
		$this->common_model->leave_type = $this->input->post('leave_type');
		$this->common_model->from = $this->input->post('from');
		$this->common_model->leave_to = $this->input->post('leave_to');
		$this->common_model->days = $this->input->post('days');
		$this->common_model->back_to = $this->input->post('back_to');
		$this->common_model->replacement = $this->input->post('replacement');
		$this->common_model->approver = $this->input->post('approver');
		$this->common_model->approver_two = $this->input->post('approver_two');
		$this->common_model->manager = $this->input->post('manager');
		$this->common_model->comment = $this->input->post('comment');
		$this->common_model->file = $_FILES['file']['name'];
		$return_data = $this->common_model->add_leave_management();
		redirect($return_data['return_url']);
	}
	public function fetch_name()
	{
	if($this->input->post('name'))
		{
		echo $this->common_model->fetch_name($this->input->post('name'));
		}
	}
	public function edit_leave_management($id){
		$data['active'] = 'leave_management';
		$data['employee'] = $this->common_model->get_employee();
		$data['leave_management'] = $this->common_model->get_management_by_id($id);
		$this->load->view('admin/leave_management/edit_leave_management',$data);
	}
	public function leave_management_edit(){
		$this->common_model->id = $this->input->post('id');
		$this->common_model->role = $this->input->post('role');
		$this->common_model->email = $this->input->post('email');
		$this->common_model->name = $this->input->post('name');
		$this->common_model->emp_id = $this->input->post('emp_id');
		$this->common_model->leave_type = $this->input->post('leave_type');
		$this->common_model->from = $this->input->post('from');
		$this->common_model->leave_to = $this->input->post('leave_to');
		$this->common_model->days = $this->input->post('days');
		$this->common_model->back_to = $this->input->post('back_to');
		$this->common_model->replacement = $this->input->post('replacement');
		$this->common_model->approver = $this->input->post('approver');
		$this->common_model->approver_two = $this->input->post('approver_two');
		$this->common_model->manager = $this->input->post('manager');
		$this->common_model->comment = $this->input->post('comment');
		$this->common_model->file = $_FILES['file']['name'];
		$return_data = $this->common_model->edit_leave_management();
		redirect($return_data['return_url']);
	}
	public function delete_leave_management($id){
		$row = $this->common_model->get_management_by_id($id);
		unlink(realpath('assets/backend/dist/upload/'.$row['image']));
		$this->db->where('id',$id);
		$this->db->delete('leave_manage_tbl');
        redirect(base_url('admin/leave-management'));
	}
	public function show_leave_details($id){
		$data['active'] = 'leave_management';
		$data['leave_management'] = $this->common_model->get_management_by_id($id);
		$this->load->view('admin/leave_management/show_leave_details',$data);
	}
	
	 
}

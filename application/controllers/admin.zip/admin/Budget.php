<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Budget extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		check_login_admin();
		$this->load->model('common_model');
	}
    public function index()
	{	
		$data['active'] = 'budget';
        $data['budgets'] = $this->common_model->get_budget();
		$this->load->view('admin/budget/index',$data);
	}
    public function add_budget(){
        $data['active'] = 'add_budget';
        $data['tasks'] = $this->common_model->get_project();
        $data['employee'] = $this->common_model->get_employee();
        $this->load->view('admin/budget/add_budget',$data);
    } 
    public function save_budget(){
        $this->common_model->task = $this->input->post('task');
        $this->common_model->category = $this->input->post('category');
        $this->common_model->sub_category = $this->input->post('sub_category');
        $this->common_model->amount = $this->input->post('amount');
        $this->common_model->upload_by = $this->input->post('upload_by');
		$this->common_model->template = $_FILES['template']['name'];
        $return_data = $this->common_model->add_budget();
        redirect($return_data['return_url']);
    }
}
?>
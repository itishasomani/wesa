<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		check_login_admin();
		get_leave();
		get_emp();
		get_assets();
		get_procurement();
	}
	public function index()
	{	
		$data['active'] = 'dashboard';
		$data['get_leave'] = get_leave($this->session->userdata('id'));
		$data['get_emp'] = get_emp($this->session->userdata('id'));
		$data['get_assets'] = get_assets($this->session->userdata('id'));
		$data['get_procurement'] = get_procurement($this->session->userdata('id'));
		$this->load->view('admin/dashboard/index',$data);
	}

}

/* End of file Dashboard.php */
/* Location:application/admin/controllers/Dashboard.php */
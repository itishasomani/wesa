<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Procurement extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		check_login_admin();
		$this->load->model('common_model');
	}
	public function index()
	{	
		$data['active'] = 'procurement';
		$data['employee'] = $this->common_model->get_employee();
		$data['address'] = $this->common_model->get_project();
		$data['emp_type'] =$this->common_model->emp_type();
		$data['Budget'] = $this->common_model->get_budget();
		$data['Sub_category'] = $this->common_model->get_budget();
		$this->load->view('admin/procurement/index',$data);
	}
    public function view_all_request(){
        $data['active'] = 'view_all_request';
		$data['request'] = $this->common_model->get_all_request();
		$this->load->view('admin/procurement/view_all_request',$data);
    }
	public function add_procurement(){
		$this->common_model->name = $this->input->post('name');
		// $this->common_model->emp_id = $this->input->post('emp_id');
		$this->common_model->item = $this->input->post('item');
		$this->common_model->quantity = $this->input->post('quantity');
		$this->common_model->unit = $this->input->post('unit');
		$this->common_model->task = $this->input->post('task');
		$this->common_model->other = $this->input->post('other');
		$this->common_model->address = $this->input->post('address');
		$this->common_model->b_category = $this->input->post('b_category');
		$this->common_model->sub_category = $this->input->post('sub_category');
		$this->common_model->approver = $this->input->post('approver');
		$this->common_model->approver_two = $this->input->post('approver_two');
		$this->common_model->approver_three = $this->input->post('approver_three');
		$this->common_model->featuredImage = $_FILES['featuredImage']['name'];
		$this->common_model->comment = $this->input->post('comment');
		$return_data = $this->common_model->add_procurement();
		redirect($return_data['return_url']);
	}
	public function edit_procurement($id){
		$data['active'] = 'procurement';
		$data['procurement'] = $this->common_model->get_procurement($id);
		$data['employee'] = $this->common_model->get_employee();
		$data['address'] = $this->common_model->get_project();
		$data['emp_type'] =$this->common_model->emp_type();
		$this->load->view('admin/procurement/edit_procurement',$data);
	}
	public function procurement_edit(){
		$this->common_model->id = $this->input->post('id');
		$this->common_model->name = $this->input->post('name');
		// $this->common_model->emp_id = $this->input->post('emp_id');
		$this->common_model->item = $this->input->post('item');
		$this->common_model->quantity = $this->input->post('quantity');
		$this->common_model->unit = $this->input->post('unit');
		$this->common_model->task = $this->input->post('task');
		$this->common_model->other = $this->input->post('other');
		$this->common_model->address = $this->input->post('address');
		$this->common_model->b_category = $this->input->post('b_category');
		$this->common_model->sub_category = $this->input->post('sub_category');
		$this->common_model->approver = $this->input->post('approver');
		$this->common_model->approver_two = $this->input->post('approver_two');
		$this->common_model->approver_three = $this->input->post('approver_three');
		$this->common_model->featuredImage = $_FILES['featuredImage']['name'];
		$this->common_model->comment = $this->input->post('comment');
		$return_data = $this->common_model->edit_procurement();
		redirect($return_data['return_url']);
	}
	public function delete_procurement($id){
		$row = $this->common_model->get_procurement($id);
		unlink(realpath('assets/backend/dist/img/'.$row['image']));
		$this->db->where('id',$id);
		$this->db->delete('procurement_tbl');
        redirect(base_url('admin/view-all-request'));
	}
	public function show_procurement($id){
		$data['active'] = 'procurement';
		$data['procurement'] = $this->common_model->get_procurement($id);
		$this->load->view('admin/procurement/show_procurement',$data);
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Leave_management extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		check_login_employee();
		$this->load->model('employee_model');
	}
    public function index()
	{	
		$data['active'] = 'employee/leave_management';
		$data['leave_detail'] = $this->employee_model->get_all_leave_detail();
		$this->load->view('employee/leave_management/index',$data);
	}
	public function add_leave_management(){
		$data['active'] = 'employee/add_leave_management';
		$data['employee'] = $this->employee_model->employee();
		$this->load->view('employee/leave_management/add_leave_management',$data);
	}
	public function save_leave_management(){
		$this->employee_model->email = $this->input->post('email');
		$this->employee_model->role = $this->input->post('role');
		$this->employee_model->name = $this->input->post('name');
		$this->employee_model->emp_id = $this->input->post('emp_id');
		$this->employee_model->leave_type = $this->input->post('leave_type');
		$this->employee_model->from = $this->input->post('from');
		$this->employee_model->leave_to = $this->input->post('leave_to');
		$this->employee_model->days = $this->input->post('days');
		$this->employee_model->back_to = $this->input->post('back_to');
		$this->employee_model->replacement = $this->input->post('replacement');
		$this->employee_model->approver = $this->input->post('approver');
		$this->employee_model->approver_two = $this->input->post('approver_two');
		$this->employee_model->manager = $this->input->post('manager');
		$this->employee_model->comment = $this->input->post('comment');
		$this->employee_model->file = $_FILES['file']['name'];
		$return_data = $this->employee_model->add_leave_management();
		redirect(base_url('employee/leave_management'));
	}
	public function fetch_name()
	{
	if($this->input->post('emp_id'))
		{
		echo $this->employee_model->fetch_name($this->input->post('emp_id'));
		}
	}
	public function edit_leave_management($id){
		$data['active'] = 'employee/leave_management';
		$data['employee'] = $this->employee_model->employee();
		$data['leave_management'] = $this->employee_model->get_management_by_id($id);
		$this->load->view('employee/leave_management/edit_leave_management',$data);
	}
	public function leave_management_edit(){
		$this->employee_model->id = $this->input->post('id');
		$this->employee_model->name = $this->input->post('name');
		$this->employee_model->emp_id = $this->input->post('emp_id');
		$this->employee_model->leave_type = $this->input->post('leave_type');
		$this->employee_model->from = $this->input->post('from');
		$this->employee_model->leave_to = $this->input->post('leave_to');
		$this->employee_model->days = $this->input->post('days');
		$this->common_model->back_to = $this->input->post('back_to');
		$this->employee_model->replacement = $this->input->post('replacement');
		$this->employee_model->approver = $this->input->post('approver');
		$this->employee_model->approver_two = $this->input->post('approver_two');
		$this->common_model->manager = $this->input->post('manager');
		$this->common_model->comment = $this->input->post('comment');
		$this->employee_model->file = $_FILES['file']['name'];
		$return_data = $this->employee_model->edit_leave_management();
		redirect(base_url('employee/leave_management'));
	}
	public function delete_leave_management($id){
		$row = $this->employee_model->get_management_by_id($id);
		$this->db->where('id',$id);
		$this->db->delete('leave_manage_tbl');
        redirect(base_url('employee/leave_management'));
	}
	public function show_leave_details($id){
		$data['active'] = 'employee/leave_management';
		$data['leave_management'] = $this->employee_model->get_management_by_id($id);
		$this->load->view('employee/leave_management/show_leave_details',$data);
	}
}
?>
<?php
class Login_model extends CI_Model {
    public function login_process(){
        $return_data = $this->login();
        if($return_data['status'] == 1 && $return_data['role'] =='admin'){
            $return_data['response_status'] = 1;
            $return_data['response_msg'] = 'Wellcome Admin';
            $return_data['return_url'] = base_url('admin/dashboard');
        }
        else if($return_data['status'] == 1 && $return_data['role'] == 'employee' && $return_data['email']== $this->email){
            $return_data['response_status'] = 1;
            $return_data['response_msg'] = 'Wellcome '.$_SESSION['name'].'';
            $return_data['return_url'] = base_url('employee/dashboard');
        }
        else{
            $return_data['response_status'] = 0;
            $return_data['response_msg'] = 'Invalid Credentials';
            $return_data['return_url'] = base_url('login');
        }
        return $return_data;
    }

    public function login(){
        $return_data = array('status'=>0);
        $this->db->where('email',$this->email);
        // $this->db->where('role','admin');
        // $this->db->or_where('role','employee');
        $this->db->select('id,name,email,role,password');
        $this->db->from('user_tbl');
        $query1 = $this->db->get_compiled_select();

        $this->db->select('id,name,email,role,password');
        $this->db->where('email',$this->email);
        $this->db->from('emp_tbl');
        $query2 = $this->db->get_compiled_select();

        $query = $this->db->query($query1 . ' UNION ' . $query2);
        $row = $query->row_array();
        $email = $row['email'];
        $role = $row['role'];
        $password =  decrypt($row['password']);
        if(!empty($row)){
            if($password == $this->password && $role == 'admin' ){
                $return_data = array('status'=>1,'role'=>'admin');
                $this->setSession($row);
            }
            else if($password == $this->password && $role == 'employee' && $email == $row['email']){
                $return_data = array('status'=>1,'role'=>'employee','email'=>$row['email']);
                $this->session($row);
            }
        }
        return $return_data;
    }

    public function setSession($arr){
        $userdata = array(
            'id'=>$arr['id'],
            'name'=>$arr['name'],
            'email'=>$arr['email'],
            'role'=>$arr['role'],
            'admin_login'=>TRUE,
        );
        $this->session->set_userdata($userdata);
    }
    public function session($arr){
        $userdata = array(
            'id'=>$arr['id'],
            'name'=>$arr['name'],
            'email'=>$arr['email'],
            'role'=>$arr['role'],
            'employee_login'=>TRUE,
        );
        $this->session->set_userdata($userdata);
    }
}